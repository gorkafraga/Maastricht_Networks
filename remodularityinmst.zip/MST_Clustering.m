function [ clustering ] = MST_Clustering( mst )
node_number = length(mst);

for kk=1:node_number            
     for ii=1:node_number
         for jj=1:node_number
             if mst(ii,jj)==0 & mst(ii,kk)~=0 & mst(kk,jj)~=0
                mst(ii,jj)=mst(ii,kk)+mst(kk,jj);
             end
         end
     end
 end
 for ii=1:node_number           
     mst(ii,ii)=0;       
 end   
 
 dis = pdist(mst,'spearman');
square = squareform(dis);
lin = linkage(dis,'average');
clustering = cluster(lin,'maxclust',3);
%  [~, T] = dendrogram(lin,0);
end



