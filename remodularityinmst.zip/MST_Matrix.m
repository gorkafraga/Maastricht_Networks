function [mst] = MST_Matrix(Original_matrix)
 Input_matrix = 1./Original_matrix; % to compute the maximum weight tree
for i = 1:length(Original_matrix);
    for j = 1:length(Original_matrix);
        if  i==j & Input_matrix(i,j)==inf;
            Input_matrix(i,j)=0;
        end
    end
end
[n,n] = size(Input_matrix);                           % The matrix is n by n, where n = # nodes.
Input_matrix; n; 

% Start with node 1 and keep track of which nodes are in tree and which are not.

intree = [1];  number_in_tree = 1;  number_of_edges = 0;
notintree = [2:n]';  number_notin_tree = n-1;

in = intree(1:number_in_tree);               % Print which nodes are in tree and which 
out = notintree(1:number_notin_tree);  % are not.

% Iterate until all n nodes are in tree.

while number_in_tree < n,

%   Find the cheapest edge from a node that is in tree to one that is not.

  mincost = Inf;                             % You can actually enter infinity into Matlab.
  for i=1:number_in_tree,               
    for j=1:number_notin_tree,
      ii = intree(i);  jj = notintree(j);
      if Input_matrix(ii,jj) < mincost, 
        mincost = Input_matrix(ii,jj); jsave = j; iisave = ii; jjsave = jj;  % Save coords of node.
      end;
    end;
  end;

%    Add this edge and associated node jjsave to tree.  Delete node jsave from list
%    of those not in tree.

  number_of_edges = number_of_edges + 1;      % Increment number of edges in tree.
  mst(number_of_edges,1) = iisave;            % Add this edge to tree.
  mst(number_of_edges,2) = jjsave;
  costs(number_of_edges,1) = mincost;

  number_in_tree = number_in_tree + 1;        % Increment number of nodes that tree connects.
  intree = [intree; jjsave];                  % Add this node to tree.
  for j=jsave+1:number_notin_tree,            % Delete this node from list of those not in tree.
    notintree(j-1) = notintree(j);
  end;
  number_notin_tree = number_notin_tree - 1;  % Decrement number of nodes not in tree.

  in = intree(1:number_in_tree);              % Print which nodes are now in tree and
  out = notintree(1:number_notin_tree); % which are not.

end;
 disp(' Edges in minimum spanning tree and their costs: ');
[mst  costs];                                 % Print out edges in minimum spanning tree.
cost = sum(costs);
A3 = ans;
mst = zeros(length(Original_matrix),length(Original_matrix));
for i = 1:(length(Original_matrix)-1)
mst(A3(i,1),A3(i,2)) = 1;
mst(A3(i,2),A3(i,1)) = 1;
end
 AA = zeros(1,length(Original_matrix));
 aa = sortrows(A3,2);
 AA(2:end) = aa(:,1);
 treeplot(AA);
 count = size(AA,2);
 [x,y] = treelayout(AA);
 x = x';
 y = y';
 name1 = cellstr(num2str((1:count)'));
 text(x(:,1),y(:,1),name1,'VerticalAlignment','bottom','HorizontalAlignment','right');
  title('Minimum Spanning Tree of weighted network');
end

